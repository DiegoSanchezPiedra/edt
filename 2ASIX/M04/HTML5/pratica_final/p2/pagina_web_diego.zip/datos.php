<?php 
echo htmlspecialchars($_POST['firstname','lastname','mail','phone','fecha','como me conociste','puntuacion','message'];
?>