Hi ha dues coses que estàn bug al direcotri de **imatges_logo**:
	1. La imatge **omega_02.jpg** no es pot obrir llavors no surt la imatge al resultat de html, per tant el que he fet és, com que ha hi ha dues imatges repetides, he canviat de nom una de les imatges repetides i la imatge que no es pot obrir (que és la original) la he canviat per **omega_02_rota.jpg**
	
	2. Al directori **logos** dins del direcotri **imatges_logos** els dos logos, tant de **Narn** com de **Earth_Alliance** són el mateixos, llavors per aquesta raó surten totes les naus amb els mateixos logos
