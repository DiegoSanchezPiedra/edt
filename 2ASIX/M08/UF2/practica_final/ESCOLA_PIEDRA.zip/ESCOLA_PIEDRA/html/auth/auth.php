<!DOCTYPE html>
<html>
    <head>
        <title>auth</title>
    </head>
    <header>
        <h1>Escola Piedra</h1>
    </header>
	<body>
        <h3>Pàgina d'Autenticació</h3>
        <p><a href="moodle/moodle.php">Moodle</a></p>
        <p><a href="ftp://localhost/Informatica/" target="_blank">Recursos</a><p>
    </body>
</html>
